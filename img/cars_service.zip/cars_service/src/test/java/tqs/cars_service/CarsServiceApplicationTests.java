package tqs.cars_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
